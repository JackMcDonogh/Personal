﻿using Microsoft.AspNetCore.Mvc;
using Personal.DAO;
using Personal.Models;

namespace Personal.Controllers;

public class HomeController : Controller

{
    public IActionResult Index()
    {
        return View();
    }

  
    //attribute routing
    public IActionResult Resume()
    {
        //list of data values for the resume model to be passed into the resume page 
        //hard coded in the education hence why its missing
        var experiences = new List<Experience>
        {
            new ()
            //listed all variables such as id etc. and gave them values to be passed into view
            {
                Id = 1,
                DateRange = "2024",
                JobTitle = "Admin Intern",
                Company = "Northwell Healthcare",
                Location = "Manhattan, New York",
                Description = "Responsible for Northwells presence in Manhattan."
            },
            new ()
            {
                Id = 2,
                DateRange = "2023",
                JobTitle = "Intern",
                Company = "JRI-America",
                Location = "Tralee, co.Kerry",
                Description = "Developed enterprise-level software solutions."
            }
            
        };
//returning the experiances into my resume view
        return View(experiences);
    }

   
    // dependency injection for the CommentDAO to interact with my comments
    private readonly CommentDAO _commentDAO = new CommentDAO();

    //get request to load the vieew with the list of comments
    public IActionResult Contact()
    {
        //this is just getting all my comments
        var comments = _commentDAO.GetAll();
        // i passed the comments to the Contact view
        return View(comments);
    }
//i added a post because i need to add comments
    [HttpPost]
    public IActionResult AddComment(Comment comment)
    {
        if (!ModelState.IsValid) return View("Contact", _commentDAO.GetAll());
        //if its not valid then the view will refresh with all current comments
        CommentDAO.Add(comment);
        //redirect the user to the view with new comments added if valid
        return RedirectToAction("Contact");
    }
    
//added this later in the project. just to delete the comments 
    [HttpPost]
    public IActionResult DeleteComment(int id)
    {
        //this is so that the comments get deleted by id
        CommentDAO.Delete(id);
        //bring user back to view with the new list 
        return RedirectToAction("Contact");
    }
    
    //this is my error 404 page. directs user to Error404.cshtml in shared folder
    public IActionResult Error404()
    {
        return View();
    }
};