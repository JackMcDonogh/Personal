using Personal.Models;

// this is the DAO for my comment section.
//Used a dao for saving in class objects as its what i did last year. 
 //looked at some tutorials as i was new to this such as: https://www.geeksforgeeks.org/data-access-object-pattern/ 
// also looked at some comments on reddit. unsure if i kept the code from it though,. https://www.reddit.com/r/csharp/comments/c66a6k/how_to_use_dao_with_c/?rdt=52997
namespace Personal.DAO
{
    public class CommentDAO
    {
        //made the list static as my ide got angry at me. the list stores the comments in memory
        private static List<Comment> comments = new List<Comment>();
//retrieves the commenbts as IEnurmerable
        public IEnumerable<Comment> GetAll() => comments;
//adds comment to list incrememting id by 1
        public static void Add(Comment comment)
        {
            comment.Id = comments.Count > 0 ? comments.Max(c => c.Id) + 1 : 1;
            comments.Add(comment);
        }
        
//this is the section for deleting comments on the page. 
//used some stuff from class such as the != and == operators
//also use lambda expression (i believe their called =>)
//it finds the comments id and deletes it based off id. did this as in large organisations its bad to delete by name
//as there could be data with same names.
        public static void Delete(int id)
        {
            var comment = comments.FirstOrDefault(c => c.Id == id);
            if (comment != null)
            {
                comments.Remove(comment);
            }
        }
    }
}

