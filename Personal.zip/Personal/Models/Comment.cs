namespace Personal.Models;
using System.ComponentModel.DataAnnotations;
//made my comment model
//used the [required] tool for model validation plus more.
public class Comment
{
    //the comments ID. etc...
    [Required]
    public int Id { get; set; }
    [Required]
    public string Name { get; set; }
    [Required]
    [EmailAddress]
    public string Email { get; set; }
    
    //used this for validation as to not have comments that are too long but also to make sure there is a message in each comment
    [Required]
    [MinLength(1)]
    [MaxLength(100)]
    public string Message { get; set; }
    public DateTime DateCreated { get; set; } = DateTime.Now;
}
