namespace Personal.Models;
//model for user experiance
//gets and set ID etc.
public class Experience
{
        public int Id { get; set; }
        public string DateRange { get; set; }
        public string JobTitle { get; set; }
        public string Company { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
        
        
}