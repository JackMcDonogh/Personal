namespace Personal.Models;

//not sure if i should keep this in or not as only really good for testing. but i did use this in the project quite a lot
public class ErrorViewModel
{
    public string? RequestId { get; set; }

    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
}